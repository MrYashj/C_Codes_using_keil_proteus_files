void delay(unsigned int time);
void lcd_cmd(unsigned char a);
void lcd_data(unsigned char b);
void lcd_str(unsigned char *str);
void lcd_init(void);
sbit en = P2^7;
sbit rs = P2^6;
#define ldata P3

void lcd_init(void)
{
  	lcd_cmd(0x38); // 8bit mode
	lcd_cmd(0x0c); // display on, cursor off
	lcd_cmd(0x01); // for clearing screen
	lcd_cmd(0x80); // force cursor to beginning of 1st line
}
void delay(unsigned int time)
{
	unsigned int i,j;
	for(i=0;i<time;i++)
		for(j=0;j<150;j++);
}
void lcd_cmd(unsigned char a)
{
	rs=0;			//Command mode
	ldata=a;
	en=1;
	delay(5);
	en=0;
	delay(5);
}
void lcd_data(unsigned char b)
{
	rs=1;			//Data mode
	ldata=b;
	en=1;
	delay(5);
	en=0;
	delay(5);
}
void lcd_str(unsigned char *str)
{
	while(*str)
	{
  		lcd_data(*str++);
	}
}