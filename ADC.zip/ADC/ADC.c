#include<reg51.h>
#include"lcd.h"

sbit rd = P2^3; 
sbit wr = P2^4;
sbit intr= P2^5;
#define mydata P1

void main(void)
{
    unsigned int value;
	char temp[4];
	int i=0;
	lcd_init();
	intr = 1;
	rd = 1;
	wr = 1;
	while(1)
	{
		lcd_cmd(0x01);
		wr = 0;
		wr = 1;
		while(intr==1);
	  	rd=0;
		value = mydata;
		while(i<3)
		{
			temp[i] = (value%10) + '0'; // For converting into ASCII
			value = value / 10;
			i++;
		}
		lcd_cmd(0x80);
		lcd_str("ANALOG DATA: ");
		lcd_cmd(0x8D);
		for(i=2;i>=0;i--)
		{
			lcd_data(temp[i]);
		}
		i=0;
		delay(500);
		rd = 1;
	}
}